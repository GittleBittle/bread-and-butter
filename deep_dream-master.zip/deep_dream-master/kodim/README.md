Sample input images, from http://r0k.us/graphics/kodak/.

The original full-size lossless images are [here](http://www.math.purdue.edu/~lucier/PHOTO_CD/BMP_IMAGES/).
